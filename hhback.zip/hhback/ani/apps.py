from django.apps import AppConfig


class AniConfig(AppConfig):
    name = 'ani'
