# from .views_cbv_generics import CompanyListAPIView, CompanyDetailAPIView, VacancyListAPIView, VacancyDetailAPIView, CompanyVacanciesAPIView
# from .views_fbv import company_list, company_detail, company_vacancies, vacancy_list, vacancy_detail
# from .views_cbv import CompanyListAPIView, CompanyDetailAPIView, VacancyListAPIView, VacancyDetailAPIView, CompanyVacanciesAPIView
from .views_cbv_generics import CompanyListAPIView, CompanyDetailAPIView, VacancyListAPIView, VacancyDetailAPIView, CompanyVacanciesAPIView